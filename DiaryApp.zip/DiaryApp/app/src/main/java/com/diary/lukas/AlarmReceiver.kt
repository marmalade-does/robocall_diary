package com.diary.lukas

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.telecom.TelecomManager
import android.util.Log

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        Log.d("DiaryApp", "Daily alarm fired — triggering incoming call")

        val telecom = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        val handle  = MainActivity.getPhoneAccountHandle(context)

        try {
            telecom.addNewIncomingCall(handle, Bundle())
        } catch (e: Exception) {
            Log.e("DiaryApp", "Failed to trigger incoming call: ${e.message}")
        }

        // Reschedule for the same time tomorrow
        val prefs  = context.getSharedPreferences(MainActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val hour   = prefs.getInt(MainActivity.PREF_HOUR, 21)
        val minute = prefs.getInt(MainActivity.PREF_MINUTE, 0)
        AlarmScheduler.scheduleDaily(context, hour, minute)
    }
}
