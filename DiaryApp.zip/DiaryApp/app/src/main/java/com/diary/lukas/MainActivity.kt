package com.diary.lukas

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.telecom.PhoneAccount
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.widget.Button
import android.widget.TimePicker
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    companion object {
        const val CHANNEL_ID_CALL    = "diary_call_channel"
        const val CHANNEL_ID_SERVICE = "diary_service_channel"
        const val PREFS_NAME  = "DiaryPrefs"
        const val PREF_HOUR   = "call_hour"
        const val PREF_MINUTE = "call_minute"
        const val PHONE_ACCOUNT_ID = "diary_account"

        fun getPhoneAccountHandle(context: Context): PhoneAccountHandle =
            PhoneAccountHandle(
                ComponentName(context, DiaryConnectionService::class.java),
                PHONE_ACCOUNT_ID
            )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        createNotificationChannels()
        requestPermissions()
        registerPhoneAccount()

        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val hour   = prefs.getInt(PREF_HOUR, 21)
        val minute = prefs.getInt(PREF_MINUTE, 0)

        val timePicker = findViewById<TimePicker>(R.id.timePicker)
        timePicker.setIs24HourView(true)
        timePicker.hour   = hour
        timePicker.minute = minute

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            val h = timePicker.hour
            val m = timePicker.minute

            // Check exact alarm permission on Android 12+
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val am = getSystemService(AlarmManager::class.java)
                if (!am.canScheduleExactAlarms()) {
                    Toast.makeText(this, "Please grant 'Alarms & Reminders' permission", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:$packageName")))
                    return@setOnClickListener
                }
            }

            prefs.edit().putInt(PREF_HOUR, h).putInt(PREF_MINUTE, m).apply()
            AlarmScheduler.scheduleDaily(this, h, m)
            Toast.makeText(
                this,
                "Diary call scheduled for ${"%02d".format(h)}:${"%02d".format(m)} daily ✓",
                Toast.LENGTH_LONG
            ).show()
        }

        // Reschedule on every app open (in case the alarm was cleared by OS)
        AlarmScheduler.scheduleDaily(this, hour, minute)
    }

    private fun registerPhoneAccount() {
        val telecom = getSystemService(TELECOM_SERVICE) as TelecomManager
        val handle  = getPhoneAccountHandle(this)
        val account = PhoneAccount.builder(handle, "Daily Diary")
            .setCapabilities(PhoneAccount.CAPABILITY_SELF_MANAGED)
            .build()
        telecom.registerPhoneAccount(account)
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            // High-importance channel wakes the screen for the incoming call
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID_CALL, "Diary Call", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Incoming diary call"
                    enableVibration(true)
                }
            )
            // Low-importance channel for the recording foreground service notification
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID_SERVICE, "Recording", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Recording in progress"
                }
            )
        }
    }

    private fun requestPermissions() {
        val needed = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.MANAGE_OWN_CALLS,
        ).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1)
        }
    }
}
