package com.diary.lukas

import android.os.Bundle
import android.telecom.TelecomManager
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Full-screen activity shown when the "call" comes in and while recording.
 * Launched by the incoming call notification's full-screen intent.
 * Shows over the lock screen so it behaves exactly like a real incoming call.
 */
class CallActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show over lock screen and turn screen on — same flags a phone call uses
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        setContentView(R.layout.activity_call)

        val telecomManager = getSystemService(TELECOM_SERVICE) as TelecomManager
        val action = intent.getStringExtra("action")

        // Handle action passed via notification buttons
        when (action) {
            "answer"  -> { telecomManager.acceptRingingCall(); updateUiToActive() }
            "decline" -> { telecomManager.endCall(); finish() }
            else      -> updateUiToRinging()
        }

        findViewById<Button>(R.id.btnAnswer).setOnClickListener {
            telecomManager.acceptRingingCall()
            updateUiToActive()
        }

        findViewById<Button>(R.id.btnHangUp).setOnClickListener {
            telecomManager.endCall()
            finish()
        }
    }

    override fun onNewIntent(intent: android.content.Intent?) {
        super.onNewIntent(intent)
        intent?.getStringExtra("action")?.let { action ->
            val telecomManager = getSystemService(TELECOM_SERVICE) as TelecomManager
            when (action) {
                "answer"  -> { telecomManager.acceptRingingCall(); updateUiToActive() }
                "decline" -> { telecomManager.endCall(); finish() }
            }
        }
    }

    private fun updateUiToRinging() {
        findViewById<TextView>(R.id.tvStatus).text   = "Incoming call..."
        findViewById<TextView>(R.id.tvCaller).text   = "Daily Diary"
        findViewById<Button>(R.id.btnAnswer).visibility  = android.view.View.VISIBLE
        findViewById<Button>(R.id.btnHangUp).visibility  = android.view.View.GONE
    }

    private fun updateUiToActive() {
        findViewById<TextView>(R.id.tvStatus).text   = "Recording..."
        findViewById<TextView>(R.id.tvCaller).text   = "Daily Diary"
        findViewById<Button>(R.id.btnAnswer).visibility  = android.view.View.GONE
        findViewById<Button>(R.id.btnHangUp).visibility  = android.view.View.VISIBLE
    }
}
