package com.diary.lukas

import android.content.Context
import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Base64
import java.util.concurrent.TimeUnit

/**
 * Uploads a recording to Google Drive using a service account.
 *
 * Setup required (one-time):
 *   1. Create a service account in Google Cloud Console
 *   2. Enable the Drive API
 *   3. Share your "Diary Recordings" Drive folder with the service account email (Editor access)
 *   4. Download the service account JSON key file
 *   5. Copy it into:  app/src/main/assets/service_account.json
 *   6. Set DRIVE_FOLDER_ID below to your folder's ID
 *      (the long string after /folders/ in the folder's Drive URL)
 */
object DriveUploader {

    // ← PASTE YOUR GOOGLE DRIVE FOLDER ID HERE
    private const val DRIVE_FOLDER_ID = "YOUR_FOLDER_ID_HERE"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun upload(context: Context, file: File) {
        val accessToken = getAccessToken(context)
        uploadFile(accessToken, file)
    }

    // ── Step 1: Create a JWT and exchange it for an OAuth2 access token ──────

    private fun getAccessToken(context: Context): String {
        val json = context.assets.open("service_account.json").bufferedReader().readText()
        val sa   = JSONObject(json)

        val clientEmail = sa.getString("client_email")
        val privateKeyPem = sa.getString("private_key")
            .replace("-----BEGIN PRIVATE KEY-----", "")
            .replace("-----END PRIVATE KEY-----", "")
            .replace("\\n", "")
            .replace("\n", "")
            .trim()

        val jwt = buildJwt(clientEmail, privateKeyPem)

        val tokenBody = "grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=$jwt"
            .toRequestBody("application/x-www-form-urlencoded".toMediaType())

        val tokenRequest = Request.Builder()
            .url("https://oauth2.googleapis.com/token")
            .post(tokenBody)
            .build()

        val response = client.newCall(tokenRequest).execute()
        val body = response.body?.string() ?: throw Exception("Empty token response")

        if (!response.isSuccessful) {
            throw Exception("Token request failed ${response.code}: $body")
        }

        return JSONObject(body).getString("access_token")
    }

    private fun buildJwt(clientEmail: String, privateKeyBase64: String): String {
        val header  = base64url("""{"alg":"RS256","typ":"JWT"}""")
        val now     = System.currentTimeMillis() / 1000
        val claims  = base64url("""
            {
              "iss": "$clientEmail",
              "scope": "https://www.googleapis.com/auth/drive.file",
              "aud": "https://oauth2.googleapis.com/token",
              "exp": ${now + 3600},
              "iat": $now
            }
        """.trimIndent())

        val signingInput = "$header.$claims"

        val keyBytes = Base64.getDecoder().decode(privateKeyBase64)
        val privateKey = KeyFactory.getInstance("RSA")
            .generatePrivate(PKCS8EncodedKeySpec(keyBytes))

        val sig = Signature.getInstance("SHA256withRSA").apply {
            initSign(privateKey)
            update(signingInput.toByteArray())
        }.sign()

        val sigEncoded = Base64.getUrlEncoder().withoutPadding().encodeToString(sig)
        return "$signingInput.$sigEncoded"
    }

    // ── Step 2: Multipart upload to Drive ────────────────────────────────────

    private fun uploadFile(accessToken: String, file: File) {
        // Metadata part — sets the filename and parent folder
        val metadata = JSONObject().apply {
            put("name", file.name)
            put("parents", org.json.JSONArray().put(DRIVE_FOLDER_ID))
        }.toString()

        val metaPart = metadata.toRequestBody("application/json; charset=utf-8".toMediaType())
        val filePart = file.asRequestBody("audio/mp4".toMediaType())

        val body = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("metadata", null, metaPart)
            .addFormDataPart("file",     file.name, filePart)
            .build()

        val request = Request.Builder()
            .url("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart")
            .post(body)
            .addHeader("Authorization", "Bearer $accessToken")
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string()

        if (!response.isSuccessful) {
            throw Exception("Drive upload failed ${response.code}: $responseBody")
        }

        Log.d("DiaryApp", "Uploaded to Drive: ${JSONObject(responseBody!!).getString("id")}")
    }

    private fun base64url(input: String): String =
        Base64.getUrlEncoder().withoutPadding().encodeToString(input.toByteArray())
}
