package com.diary.lukas

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.MediaRecorder
import android.os.Build
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telecom.Connection
import android.telecom.DisconnectCause
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class DiaryConnection(private val context: Context) : Connection() {

    companion object {
        const val NOTIF_ID_RINGING   = 1001
        const val NOTIF_ID_RECORDING = 1002
        const val ACTION_ANSWER  = "com.diary.lukas.ACTION_ANSWER"
        const val ACTION_DECLINE = "com.diary.lukas.ACTION_DECLINE"

        // Prompt Matthew will speak
        const val DIARY_PROMPT = "Hi Lukas! How was your day? Please cover: what did you do today, what went well, and what went badly."
    }

    private var tts: TextToSpeech? = null
    private var recorder: MediaRecorder? = null
    private var outputFile: File? = null

    init {
        // Mark this as a self-managed call (like WhatsApp)
        connectionProperties = PROPERTY_SELF_MANAGED
        connectionCapabilities = CAPABILITY_MUTE or CAPABILITY_DISCONNECT_FROM_SELF
        showIncomingCallNotification()
    }

    // ── Called when user swipes/taps Answer ─────────────────────────────────

    override fun onAnswer() {
        Log.d("DiaryApp", "Call answered")
        cancelRingingNotification()
        setActive()
        showRecordingNotification()

        // Launch CallActivity for visual feedback (optional but nice)
        val callIntent = Intent(context, CallActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        context.startActivity(callIntent)

        startTtsThenRecord()
    }

    // ── Called when user taps Decline ────────────────────────────────────────

    override fun onDisconnect() {
        Log.d("DiaryApp", "Call disconnected")
        stopRecordingAndUpload()
        cancelAllNotifications()
        setDisconnected(DisconnectCause(DisconnectCause.LOCAL))
        destroy()
    }

    // ── TTS → then start recording ───────────────────────────────────────────

    private fun startTtsThenRecord() {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                // Use UK English for a British-sounding voice
                tts?.language = Locale.UK

                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onError(utteranceId: String?) {
                        Log.e("DiaryApp", "TTS error — starting recording anyway")
                        startRecording()
                    }
                    override fun onDone(utteranceId: String?) {
                        Log.d("DiaryApp", "TTS done — starting recording")
                        startRecording()
                    }
                })

                tts?.speak(DIARY_PROMPT, TextToSpeech.QUEUE_FLUSH, null, "diary_prompt")
            } else {
                Log.e("DiaryApp", "TTS init failed — starting recording without prompt")
                startRecording()
            }
        }
    }

    // ── MediaRecorder setup ──────────────────────────────────────────────────

    private fun startRecording() {
        val timestamp = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val dir = File(context.filesDir, "recordings").apply { mkdirs() }
        outputFile = File(dir, "diary_$timestamp.mp4")

        recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }

        recorder?.apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioSamplingRate(44100)
            setAudioEncodingBitRate(128000)
            setOutputFile(outputFile!!.absolutePath)
            prepare()
            start()
        }

        Log.d("DiaryApp", "Recording started → ${outputFile!!.absolutePath}")
    }

    // ── Stop recording and upload to Drive ───────────────────────────────────

    private fun stopRecordingAndUpload() {
        tts?.stop()
        tts?.shutdown()
        tts = null

        try {
            recorder?.stop()
            recorder?.release()
            recorder = null
        } catch (e: Exception) {
            Log.e("DiaryApp", "Recorder stop error: ${e.message}")
        }

        val file = outputFile ?: return
        if (!file.exists() || file.length() == 0L) {
            Log.w("DiaryApp", "No recording to upload")
            return
        }

        Log.d("DiaryApp", "Recording saved: ${file.name} (${file.length()} bytes) — uploading to Drive")

        // Upload asynchronously so we don't block the telecom callback
        CoroutineScope(Dispatchers.IO).launch {
            try {
                DriveUploader.upload(context, file)
                Log.d("DiaryApp", "Upload complete")
                // Delete local file after successful upload to save space
                file.delete()
            } catch (e: Exception) {
                Log.e("DiaryApp", "Upload failed: ${e.message}")
                // File stays locally if upload fails — can retry later
            }
        }
    }

    // ── Notifications ────────────────────────────────────────────────────────

    private fun showIncomingCallNotification() {
        val nm = context.getSystemService(NotificationManager::class.java)

        // Full-screen intent → wakes the screen and shows this like a phone call
        val fullScreenIntent = Intent(context, CallActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("is_ringing", true)
        }
        val fullScreenPi = PendingIntent.getActivity(
            context, 0, fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Answer action
        val answerIntent = Intent(context, CallActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("action", "answer")
        }
        val answerPi = PendingIntent.getActivity(
            context, 1, answerIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Decline action
        val declineIntent = Intent(context, CallActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("action", "decline")
        }
        val declinePi = PendingIntent.getActivity(
            context, 2, declineIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, MainActivity.CHANNEL_ID_CALL)
            .setSmallIcon(android.R.drawable.ic_menu_call)
            .setContentTitle("Daily Diary")
            .setContentText("Your daily check-in is calling...")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setFullScreenIntent(fullScreenPi, true)
            .setOngoing(true)
            .setAutoCancel(false)
            .addAction(android.R.drawable.ic_menu_call,  "Answer",  answerPi)
            .addAction(android.R.drawable.ic_delete,      "Decline", declinePi)
            .build()

        nm.notify(NOTIF_ID_RINGING, notification)
    }

    private fun showRecordingNotification() {
        val nm = context.getSystemService(NotificationManager::class.java)

        // Tap notification to open call screen
        val openIntent = Intent(context, CallActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openPi = PendingIntent.getActivity(
            context, 3, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, MainActivity.CHANNEL_ID_SERVICE)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Recording diary entry...")
            .setContentText("Tap to open • Hang up to save")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setContentIntent(openPi)
            .build()

        nm.notify(NOTIF_ID_RECORDING, notification)
    }

    private fun cancelRingingNotification() {
        context.getSystemService(NotificationManager::class.java).cancel(NOTIF_ID_RINGING)
    }

    private fun cancelAllNotifications() {
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.cancel(NOTIF_ID_RINGING)
        nm.cancel(NOTIF_ID_RECORDING)
    }
}
