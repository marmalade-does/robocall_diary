package com.diary.lukas

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {

            Log.d("DiaryApp", "Boot completed — rescheduling daily alarm")
            val prefs  = context.getSharedPreferences(MainActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val hour   = prefs.getInt(MainActivity.PREF_HOUR, 21)
            val minute = prefs.getInt(MainActivity.PREF_MINUTE, 0)
            AlarmScheduler.scheduleDaily(context, hour, minute)
        }
    }
}
